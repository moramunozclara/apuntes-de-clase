const Lugares = () => {
    return (  );
}
 
export default Lugares;